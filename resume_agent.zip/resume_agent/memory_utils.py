# memory_utils.py
import json

def update_memory(new_skill):
    # Load memory
    with open("memory.json", "r") as f:
        memory = json.load(f)

    # Add new preferred skill if not exists
    if new_skill not in memory["preferred_skills"]:
        memory["preferred_skills"].append(new_skill)
        memory["skill_weights"][new_skill] = 1

        with open("memory.json", "w") as f:
            json.dump(memory, f, indent=4)