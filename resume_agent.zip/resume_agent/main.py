import os
import json
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from typing import List

load_dotenv()

# ----------------------------
# 1️⃣ Load Recruiter Memory
# ----------------------------
with open("memory.json", "r") as f:
    memory = json.load(f)

# ----------------------------
# 2️⃣ Define Structured Schema
# ----------------------------
class Candidate(BaseModel):
    name: str = Field(description="Candidate full name")
    skills: List[str] = Field(description="List of technical skills only")
    experience_years: int = Field(description="Total years of experience")

# ----------------------------
# 3️⃣ Initialize LLM (Agent Brain)
# ----------------------------
llm = ChatGroq(
    model="llama-3.1-8b-instant",
    temperature=0
)

structured_llm = llm.with_structured_output(Candidate)

# ----------------------------
# 4️⃣ Bias Protection Prompt
# ----------------------------
prompt = ChatPromptTemplate.from_template("""
You are a resume screening agent.

Extract ONLY:
- Candidate name
- Technical skills
- Years of experience

IGNORE:
- Gender
- Age
- Nationality
- Religion
- University ranking

Return structured JSON only.
Resume:
{resume}
""")

# ----------------------------
# 5️⃣ Load Resumes
# ----------------------------
candidates = []

for file in os.listdir("data"):
    if file.endswith(".txt"):
        with open(os.path.join("data", file), "r", encoding="utf-8") as f:
            resume_text = f.read()

        chain = prompt | structured_llm
        candidate = chain.invoke({"resume": resume_text})
        candidate_dict = candidate.model_dump()
        candidates.append(candidate_dict)

# ----------------------------
# 6️⃣ Conflict Resolution + Weighted Scoring
# ----------------------------
for c in candidates:
    score = 0
    matched = []
    c["status"] = "Rejected"
    c["conflict_reason"] = None
    c["matched_skills"] = []
    c["score"] = 0

    # Skill scoring
    for skill in c.get("skills", []):
        skill_clean = skill.strip().lower()
        for mem_skill in memory["skill_weights"]:
            if skill_clean == mem_skill.lower():
                score += memory["skill_weights"][mem_skill]
                matched.append(mem_skill)

    # Mandatory skill check
    missing_mandatory = [
        skill for skill in memory["mandatory_skills"]
        if skill not in c.get("skills", [])
    ]
    if missing_mandatory:
        c["status"] = "Rejected"
        c["conflict_reason"] = f"Missing mandatory skills: {missing_mandatory}"
    else:
        c["status"] = "Accepted"

    # Preferred skills bonus
    for pref_skill in memory.get("preferred_skills", []):
        if pref_skill.lower() in [s.lower() for s in c.get("skills", [])]:
            score += 2  # extra points for preferred skills

    # Experience bonus
    score += c.get("experience_years", 0)

    c["matched_skills"] = matched
    c["score"] = score

# ----------------------------
# 7️⃣ Re-ranking
# ----------------------------
candidates_sorted = sorted(
    candidates,
    key=lambda x: (x.get("status") == "Accepted", x.get("score", 0)),
    reverse=True
)

# ----------------------------
# 8️⃣ Save to file (frontend-safe)
# ----------------------------
with open("candidates.json", "w") as f:
    json.dump(candidates_sorted, f, indent=4)

print("Screening complete!")