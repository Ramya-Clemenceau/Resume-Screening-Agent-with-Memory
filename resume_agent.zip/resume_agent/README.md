🚀 Resume Screening Agent with Memory (UC #18)

>An AI-powered Resume Screening Agent built using Flask + Groq LLM + Structured Extraction that:
>Extracts candidate details using structured JSON
>Applies recruiter preference memory
>Avoids bias
>Performs weighted scoring
>Re-ranks candidates automatically

## Objective

Build an intelligent resume screening system that:

Extracts candidate name, technical skills, and experience

Remembers recruiter skill preferences

Avoids bias (gender, age, nationality, etc.)

Scores candidates based on relevance

Re-ranks applicants automatically

## Use Case

UC #18 – Resume Screening Agent with Memory
Level: Medium
Category: Agent + Structured Extraction

## System Architecture
Frontend (HTML + JS)
        ↓
Flask Backend (API Layer)
        ↓
LLM Agent (Groq + Structured Output)
        ↓
Memory + Scoring Engine
        ↓
Ranked Candidates Output
📌 Requirements Implementation (5/5)
✅ R1 – Structured JSON Extraction

Uses Pydantic schema
Enforces strict JSON output from LLM

Extracts only:
Name
Technical skills
Experience

✅ R2 – Preference Memory

Stored in:
memory.json

Includes:
mandatory_skills
preferred_skills
skill_weights

Recruiter can dynamically update preferred skills via frontend.

✅ R3 – Conflict Resolution

If mandatory skills are missing → Candidate is automatically Rejected
Conflict reason is shown in frontend

✅ R4 – Relevance Scoring

Weighted scoring system:
Skill weights from memory
Preferred skill bonus (+2)
Experience bonus
Final numerical score

✅ R5 – Re-ranking

Candidates are sorted by:
Accepted candidates first
Highest score on top

🛠️ Tech Stack

Python
Flask
Groq (LLM)
LangChain
Pydantic
HTML + JavaScript
CORS

📂 Project Structure
resume_screening_agent/
│
├── app.py                 # Flask backend
├── main.py                # LLM screening logic
├── memory_utils.py        # Memory update logic
├── memory.json            # Recruiter preferences
├── data/                  # Resume .txt files
│
├── index.html          # UI
│
├── .env                   # GROQ API key
└── README.md
🔐 Setup Instructions
1️⃣ Clone Repository
git clone https://github.com/your-username/resume-screening-agent.git
cd resume-screening-agent

2️⃣ Create Virtual Environment
python -m venv venv

Activate:

Windows
venv\Scripts\activate

Mac/Linux
source venv/bin/activate

3️⃣ Install Dependencies
pip install flask flask-cors python-dotenv langchain langchain-groq pydantic

4️⃣ Add Groq API Key

Create .env file:

GROQ_API_KEY=your_groq_api_key_here

5️⃣ Add Resumes

Place .txt resume files inside:
data/

6️⃣ Run Backend
python app.py

Server runs at:
http://127.0.0.1:5000

7️⃣ Open Frontend

Open:
index.html
in your browser.

🖥️ How to Use
🔹 Run Screening

Click:
Run Screening

System will:
Parse resumes

Extract structured data
Score candidates
Rank them
Display results

🔹 Update Memory

Enter a new preferred skill and click:

Update Memory
This updates recruiter preference dynamically.

⚖️ Bias Protection

Prompt explicitly ignores:
Gender
Age
Religion
Nationality
University ranking
Ensures fair technical evaluation only.

📊 Scoring Logic
Total Score =
    Skill Weights
  + Preferred Skill Bonus
  + Experience Years
🧩 Example Output
{
  "name": "John Doe",
  "status": "Accepted",
  "experience_years": 5,
  "score": 18,
  "matched_skills": ["Python", "Machine Learning"],
  "conflict_reason": null
}
🚀 Key Features

✔ Structured LLM output
✔ Memory-based screening
✔ Conflict resolution
✔ Weighted scoring
✔ Automatic ranking
✔ Simple UI
✔ Bias control

🔮 Future Improvements

Database integration
Authentication system
Resume PDF parsing
Dashboard analytics
Vector-based skill matching (RAG extension)
Bias audit logs

👨‍💻 Author

Built as part of Agent + Structured Extraction Use Case Implementation