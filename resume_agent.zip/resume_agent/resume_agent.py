
import os
from dotenv import load_dotenv

from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_groq import ChatGroq


# 1️⃣ Load .env and get GROQ key
load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("GROQ_API_KEY not set in .env")

# 2️⃣ Load all resumes from "data" folder
documents = []
data_folder = "data"
for file_name in os.listdir(data_folder):
    if file_name.endswith(".txt"):
        loader = TextLoader(os.path.join(data_folder, file_name))
        docs = loader.load()
        documents.extend(docs)
print(f"✅ Loaded {len(documents)} documents")

# 3️⃣ Split text for RAG
text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=50)
split_docs = text_splitter.split_documents(documents)
print(f"✅ Split into {len(split_docs)} chunks")

# 4️⃣ Create embeddings + FAISS vectorstore
embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = FAISS.from_documents(split_docs, embeddings)
print("✅ FAISS vectorstore created")

# 5️⃣ Initialize GROQ LLM
llm = ChatGroq(model="gpt-4o", temperature=0, groq_api_key=GROQ_API_KEY)

# 6️⃣ Define structured JSON extraction prompt
prompt_template = """
You are a Resume Screening Assistant.
Extract candidate info in JSON:
Name, Email, Phone, Age, Skills, Projects, Experience, Education, Extracurricular
Also, score relevance for the role: 1-10.

Resume: {context}
Question: {question}

JSON Output:
"""

PROMPT = PromptTemplate(template=prompt_template, input_variables=["context", "question"])

# 7️⃣ Setup RetrievalQA chain
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=vectorstore.as_retriever(search_kwargs={"k":5}),
    chain_type_kwargs={"prompt": PROMPT},
    return_source_documents=True
)

# 8️⃣ Query example
query = "Find Python developers with ML experience"
result = qa_chain({"query": query})

# 9️⃣ Print output
print("✅ Structured Response:")
print(result['result'])

print("\n✅ Source Documents:")
for doc in result['source_documents']:
    print("-", doc.page_content[:150].replace("\n"," "), "...")