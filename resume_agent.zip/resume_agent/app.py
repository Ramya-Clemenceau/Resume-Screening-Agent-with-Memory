from flask import Flask, jsonify, request
from flask_cors import CORS
import subprocess
import json
from memory_utils import update_memory

app = Flask(__name__)
CORS(app)

screened_candidates = []

# -------------------------------
# Run Screening
# -------------------------------
@app.route("/screen-resumes", methods=["POST"])
def screen_resumes():
    global screened_candidates
    try:
        # Run main.py
        subprocess.run(["python", "main.py"], check=True)
        
        # Load screened candidates
        with open("candidates.json", "r") as f:
            screened_candidates = json.load(f)

        return jsonify({"message": "Screening complete!", "candidates": screened_candidates})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------------------------------
# Get Candidates
# -------------------------------
@app.route("/candidates", methods=["GET"])
def get_candidates():
    return jsonify(screened_candidates)

# -------------------------------
# Update Memory
# -------------------------------
@app.route("/update-memory", methods=["POST"])
def add_memory():
    try:
        data = request.json
        skill = data.get("skill")
        if not skill:
            return jsonify({"error": "No skill provided"}), 400

        update_memory(skill)
        return jsonify({"message": "Memory updated successfully!"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------------------------------
# Run App
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)